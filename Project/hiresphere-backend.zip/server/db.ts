import Database from 'better-sqlite3';

export const db = new Database(process.env.DB_PATH || 'hiresphere.db');
db.pragma('journal_mode = WAL');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL,
  data TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS jobs (
  id TEXT PRIMARY KEY,
  recruiter_id TEXT NOT NULL,
  data TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_jobs_recruiter ON jobs(recruiter_id);
CREATE TABLE IF NOT EXISTS applications (
  id TEXT PRIMARY KEY,
  job_id TEXT NOT NULL,
  candidate_id TEXT NOT NULL,
  data TEXT NOT NULL,
  UNIQUE(job_id, candidate_id)
);
CREATE INDEX IF NOT EXISTS idx_apps_candidate ON applications(candidate_id);
`);

export const parse = <T>(row: { data: string } | undefined): T | null =>
  row ? (JSON.parse(row.data) as T) : null;
