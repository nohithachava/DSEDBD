import bcrypt from 'bcryptjs';
import { db } from './db';
import { INITIAL_JOBS } from '../src/data/mockJobs';
import {
  REGISTERED_TALENT_POOL, INITIAL_CANDIDATE_PROFILE, INITIAL_RECRUITER_PROFILE, INITIAL_APPLICATIONS,
} from '../src/data/sampleResumes';

const DEFAULT_PASSWORD = 'password123';
const idByEmail: Record<string, string> = {};

const insUser = db.prepare('INSERT OR IGNORE INTO users (id,email,password_hash,role,data) VALUES (?,?,?,?,?)');
for (const u of [INITIAL_CANDIDATE_PROFILE, INITIAL_RECRUITER_PROFILE, ...REGISTERED_TALENT_POOL]) {
  const email = u.email.toLowerCase();
  const { password, ...profile } = u as any;
  idByEmail[email] = u.id;
  insUser.run(u.id, email, bcrypt.hashSync(password || DEFAULT_PASSWORD, 10), u.role, JSON.stringify({ ...profile, email }));
}

const insJob = db.prepare('INSERT OR IGNORE INTO jobs (id,recruiter_id,data) VALUES (?,?,?)');
for (const j of INITIAL_JOBS) {
  const rid = idByEmail[j.recruiterEmail?.toLowerCase()] || INITIAL_RECRUITER_PROFILE.id;
  insJob.run(j.id, rid, JSON.stringify({ ...j, recruiterId: rid }));
}

const insApp = db.prepare('INSERT OR IGNORE INTO applications (id,job_id,candidate_id,data) VALUES (?,?,?,?)');
for (const a of INITIAL_APPLICATIONS) insApp.run(a.id, a.jobId, a.candidateId, JSON.stringify(a));

console.log(`Seeded users, ${INITIAL_JOBS.length} jobs, ${INITIAL_APPLICATIONS.length} applications.`);
console.log(`Seed accounts without their own password use: "${DEFAULT_PASSWORD}"`);
