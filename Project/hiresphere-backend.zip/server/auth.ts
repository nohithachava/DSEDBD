import jwt from 'jsonwebtoken';
import type { Request, Response, NextFunction } from 'express';

const SECRET =
  process.env.JWT_SECRET ||
  (process.env.NODE_ENV === 'production'
    ? (() => { throw new Error('JWT_SECRET must be set in production'); })()
    : 'dev-secret-change-me');

export interface AuthUser { id: string; email: string; role: string }
export interface AuthedRequest extends Request { user?: AuthUser }

export const signToken = (u: AuthUser) =>
  jwt.sign({ id: u.id, email: u.email, role: u.role }, SECRET, { expiresIn: '7d' });

export function requireAuth(req: AuthedRequest, res: Response, next: NextFunction) {
  const h = req.headers.authorization;
  if (!h?.startsWith('Bearer ')) return res.status(401).json({ error: 'Not authenticated' });
  try {
    req.user = jwt.verify(h.slice(7), SECRET) as AuthUser;
    next();
  } catch {
    res.status(401).json({ error: 'Invalid or expired token' });
  }
}

// 'seeker' matches both 'jobseeker' and legacy 'candidate' roles
export const requireRole = (kind: 'recruiter' | 'seeker') =>
  (req: AuthedRequest, res: Response, next: NextFunction) => {
    const r = req.user?.role;
    const ok = kind === 'recruiter' ? r === 'recruiter' : r === 'jobseeker' || r === 'candidate';
    if (!ok) return res.status(403).json({ error: `Only ${kind}s can do this` });
    next();
  };
