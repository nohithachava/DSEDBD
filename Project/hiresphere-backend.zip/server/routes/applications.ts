import { Router } from 'express';
import { randomUUID } from 'crypto';
import { z } from 'zod';
import { db, parse } from '../db';
import { requireAuth, requireRole, AuthedRequest } from '../auth';
import { evaluateCandidateForJob } from '../../src/utils/matchingEngine';
import type { Job, JobApplication, UserProfile } from '../../src/types';

export const applicationsRouter = Router();
applicationsRouter.use(requireAuth);

const STATUSES = ['Applied', 'Under Review', 'Shortlisted', 'Interview Scheduled', 'Offered', 'Rejected'] as const;

const getJob = (id: string) => parse<Job>(db.prepare('SELECT data FROM jobs WHERE id = ?').get(id) as any);
const getApp = (id: string) => parse<JobApplication>(db.prepare('SELECT data FROM applications WHERE id = ?').get(id) as any);

// Job seeker applies (match score computed server-side)
applicationsRouter.post('/', requireRole('seeker'), (req: AuthedRequest, res) => {
  const p = z.object({
    jobId: z.string(), coverNote: z.string().max(5000).default(''), resumeData: z.any().optional(),
  }).safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: 'Invalid application' });

  const job = getJob(p.data.jobId);
  if (!job) return res.status(404).json({ error: 'Job not found' });
  const user = parse<UserProfile>(db.prepare('SELECT data FROM users WHERE id = ?').get(req.user!.id) as any)!;

  const dup = db.prepare('SELECT 1 FROM applications WHERE job_id = ? AND candidate_id = ?').get(job.id, user.id);
  if (dup) return res.status(409).json({ error: 'You already applied to this job' });

  const ev = evaluateCandidateForJob(p.data.resumeData ?? user, job);
  const app: JobApplication = {
    id: `app-${randomUUID()}`, jobId: job.id, jobTitle: job.title, company: job.company,
    candidateId: user.id, candidateName: user.fullName, candidateEmail: user.email,
    candidatePhone: user.phone, candidateTitle: user.title, candidateLocation: user.location,
    matchScore: ev.score, matchedSkills: ev.matchedSkills, missingSkills: ev.missingSkills,
    appliedDate: new Date().toISOString(), status: 'Applied',
    coverNote: p.data.coverNote, resumeData: p.data.resumeData,
  };
  db.transaction(() => {
    db.prepare('INSERT INTO applications (id,job_id,candidate_id,data) VALUES (?,?,?,?)')
      .run(app.id, app.jobId, app.candidateId, JSON.stringify(app));
    job.applicantsCount = (job.applicantsCount || 0) + 1;
    db.prepare('UPDATE jobs SET data = ? WHERE id = ?').run(JSON.stringify(job), job.id);
  })();
  res.status(201).json({ application: app, evaluation: ev });
});

// Job seeker: my applications
applicationsRouter.get('/mine', requireRole('seeker'), (req: AuthedRequest, res) => {
  const rows = db.prepare('SELECT data FROM applications WHERE candidate_id = ?').all(req.user!.id) as any[];
  res.json({ applications: rows.map(r => JSON.parse(r.data)) });
});

// Recruiter: all applications for my jobs (optional ?jobId=), best match first
applicationsRouter.get('/recruiter', requireRole('recruiter'), (req: AuthedRequest, res) => {
  const { jobId } = req.query as { jobId?: string };
  const rows = db.prepare(`
    SELECT a.data FROM applications a JOIN jobs j ON j.id = a.job_id
    WHERE j.recruiter_id = ? ${jobId ? 'AND a.job_id = ?' : ''}`)
    .all(...(jobId ? [req.user!.id, jobId] : [req.user!.id])) as any[];
  const applications = rows.map(r => JSON.parse(r.data) as JobApplication)
    .sort((a, b) => b.matchScore - a.matchScore);
  res.json({ applications });
});

// Recruiter updates status
applicationsRouter.patch('/:id/status', requireRole('recruiter'), (req: AuthedRequest, res) => {
  const p = z.object({ status: z.enum(STATUSES) }).safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: 'Invalid status', allowed: STATUSES });
  const app = getApp(req.params.id);
  if (!app) return res.status(404).json({ error: 'Application not found' });
  const job = getJob(app.jobId);
  if (!job || job.recruiterId !== req.user!.id) return res.status(403).json({ error: 'Not your job posting' });
  app.status = p.data.status;
  db.prepare('UPDATE applications SET data = ? WHERE id = ?').run(JSON.stringify(app), app.id);
  res.json({ application: app });
});

// Job seeker withdraws
applicationsRouter.delete('/:id', requireRole('seeker'), (req: AuthedRequest, res) => {
  const app = getApp(req.params.id);
  if (!app || app.candidateId !== req.user!.id) return res.status(404).json({ error: 'Application not found' });
  db.transaction(() => {
    db.prepare('DELETE FROM applications WHERE id = ?').run(app.id);
    const job = getJob(app.jobId);
    if (job) {
      job.applicantsCount = Math.max(0, (job.applicantsCount || 1) - 1);
      db.prepare('UPDATE jobs SET data = ? WHERE id = ?').run(JSON.stringify(job), job.id);
    }
  })();
  res.json({ ok: true });
});
