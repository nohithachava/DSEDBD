import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { randomUUID } from 'crypto';
import { z } from 'zod';
import { db, parse } from '../db';
import { signToken, requireAuth, AuthedRequest } from '../auth';
import type { UserProfile } from '../../src/types';

export const authRouter = Router();
export const usersRouter = Router();

const PROTECTED = ['id', 'email', 'role', 'password', 'createdAt'];
const strip = (o: Record<string, any>) =>
  Object.fromEntries(Object.entries(o).filter(([k]) => !PROTECTED.includes(k)));

const signup = z.object({
  email: z.string().email(),
  password: z.string().min(4).max(200),
  role: z.enum(['jobseeker', 'recruiter']),
  fullName: z.string().min(1).max(200),
  profile: z.record(z.string(), z.any()).optional(),
});
const login = z.object({ email: z.string().email(), password: z.string().min(1) });

const getByEmail = (email: string) =>
  db.prepare('SELECT * FROM users WHERE email = ?').get(email.toLowerCase()) as any;

authRouter.post('/signup', (req, res) => {
  const p = signup.safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: 'Invalid input', details: p.error.flatten() });
  const { email, password, role, fullName, profile } = p.data;
  if (getByEmail(email)) return res.status(409).json({ error: 'Email already registered' });

  const user: UserProfile = {
    phone: '', location: '', title: '', summary: '', experienceYears: 0,
    experienceLevel: 'Entry Level', skills: [], interests: [], education: [],
    workHistory: [], certifications: [], portfolioLinks: {},
    ...strip(profile || {}),
    id: randomUUID(), email: email.toLowerCase(), role, fullName,
    createdAt: new Date().toISOString(),
  } as UserProfile;

  db.prepare('INSERT INTO users (id,email,password_hash,role,data) VALUES (?,?,?,?,?)')
    .run(user.id, user.email, bcrypt.hashSync(password, 10), role, JSON.stringify(user));
  res.status(201).json({ token: signToken(user), user });
});

authRouter.post('/login', (req, res) => {
  const p = login.safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: 'Email and password required' });
  const row = getByEmail(p.data.email);
  if (!row || !bcrypt.compareSync(p.data.password, row.password_hash))
    return res.status(401).json({ error: 'Incorrect email or password' });
  res.json({ token: signToken(row), user: parse<UserProfile>(row) });
});

authRouter.get('/me', requireAuth, (req: AuthedRequest, res) => {
  const row = db.prepare('SELECT data FROM users WHERE id = ?').get(req.user!.id) as any;
  if (!row) return res.status(404).json({ error: 'User not found' });
  res.json({ user: parse<UserProfile>(row) });
});

// Update own profile
usersRouter.put('/me', requireAuth, (req: AuthedRequest, res) => {
  const row = db.prepare('SELECT data FROM users WHERE id = ?').get(req.user!.id) as any;
  if (!row) return res.status(404).json({ error: 'User not found' });
  const updated = { ...parse<UserProfile>(row)!, ...strip(req.body || {}) };
  db.prepare('UPDATE users SET data = ? WHERE id = ?').run(JSON.stringify(updated), req.user!.id);
  res.json({ user: updated });
});

// Change password
usersRouter.put('/me/password', requireAuth, (req: AuthedRequest, res) => {
  const p = z.object({ currentPassword: z.string(), newPassword: z.string().min(4) }).safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: 'Invalid input' });
  const row = db.prepare('SELECT password_hash FROM users WHERE id = ?').get(req.user!.id) as any;
  if (!row || !bcrypt.compareSync(p.data.currentPassword, row.password_hash))
    return res.status(401).json({ error: 'Current password is incorrect' });
  db.prepare('UPDATE users SET password_hash = ? WHERE id = ?')
    .run(bcrypt.hashSync(p.data.newPassword, 10), req.user!.id);
  res.json({ ok: true });
});
