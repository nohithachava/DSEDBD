import { Router } from 'express';
import { db } from '../db';
import { requireAuth, requireRole } from '../auth';
import { evaluateCandidateForJob } from '../../src/utils/matchingEngine';
import type { Job, UserProfile } from '../../src/types';

export const talentRouter = Router();
talentRouter.use(requireAuth, requireRole('recruiter'));

// Talent pool: all job seekers. Pass ?jobId= to rank them against a job.
talentRouter.get('/', (req, res) => {
  const rows = db.prepare("SELECT data FROM users WHERE role IN ('jobseeker','candidate')").all() as any[];
  let candidates = rows.map(r => JSON.parse(r.data) as UserProfile);
  const jobId = req.query.jobId as string | undefined;
  if (jobId) {
    const jr = db.prepare('SELECT data FROM jobs WHERE id = ?').get(jobId) as any;
    if (!jr) return res.status(404).json({ error: 'Job not found' });
    const job = JSON.parse(jr.data) as Job;
    const ranked = candidates
      .map(c => ({ candidate: c, evaluation: evaluateCandidateForJob(c, job) }))
      .sort((a, b) => b.evaluation.score - a.evaluation.score);
    return res.json({ candidates: ranked });
  }
  res.json({ candidates: candidates.map(candidate => ({ candidate })) });
});
