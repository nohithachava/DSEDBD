import { Router } from 'express';
import { randomUUID } from 'crypto';
import { z } from 'zod';
import { db, parse } from '../db';
import { requireAuth, requireRole, AuthedRequest } from '../auth';
import type { Job } from '../../src/types';

export const jobsRouter = Router();

const jobBody = z.object({
  title: z.string().min(1), company: z.string().min(1), location: z.string().min(1),
  description: z.string().min(1),
  type: z.enum(['Full-Time', 'Part-Time', 'Contract', 'Remote', 'Hybrid']).default('Full-Time'),
  experienceRequired: z.string().default(''),
  minExperienceYears: z.number().min(0).default(0),
  salary: z.string().default(''),
  skills: z.array(z.string()).default([]),
  category: z.string().default('General'),
  responsibilities: z.array(z.string()).default([]),
  requirements: z.array(z.string()).default([]),
  isFeatured: z.boolean().optional(),
});

const load = (id: string) =>
  parse<Job>(db.prepare('SELECT data FROM jobs WHERE id = ?').get(id) as any);

// Public: list + search (?q=&category=&type=&location=&minExp=)
jobsRouter.get('/', (req, res) => {
  const { q, category, type, location } = req.query as Record<string, string | undefined>;
  let jobs = (db.prepare('SELECT data FROM jobs').all() as any[]).map(r => JSON.parse(r.data) as Job);
  if (q) {
    const n = q.toLowerCase();
    jobs = jobs.filter(j =>
      [j.title, j.company, j.description, ...j.skills].join(' ').toLowerCase().includes(n));
  }
  if (category) jobs = jobs.filter(j => j.category === category);
  if (type) jobs = jobs.filter(j => j.type === type);
  if (location) jobs = jobs.filter(j => j.location.toLowerCase().includes(location.toLowerCase()));
  jobs.sort((a, b) => +new Date(b.postedDate) - +new Date(a.postedDate));
  res.json({ jobs });
});

// Recruiter: own postings
jobsRouter.get('/mine', requireAuth, requireRole('recruiter'), (req: AuthedRequest, res) => {
  const rows = db.prepare('SELECT data FROM jobs WHERE recruiter_id = ?').all(req.user!.id) as any[];
  res.json({ jobs: rows.map(r => JSON.parse(r.data)) });
});

jobsRouter.get('/:id', (req, res) => {
  const job = load(req.params.id);
  job ? res.json({ job }) : res.status(404).json({ error: 'Job not found' });
});

jobsRouter.post('/', requireAuth, requireRole('recruiter'), (req: AuthedRequest, res) => {
  const p = jobBody.safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: 'Invalid job', details: p.error.flatten() });
  const job: Job = {
    ...p.data, id: `job-${randomUUID()}`, recruiterId: req.user!.id,
    recruiterEmail: req.user!.email, postedDate: new Date().toISOString(), applicantsCount: 0,
  };
  db.prepare('INSERT INTO jobs (id,recruiter_id,data) VALUES (?,?,?)')
    .run(job.id, job.recruiterId, JSON.stringify(job));
  res.status(201).json({ job });
});

jobsRouter.put('/:id', requireAuth, requireRole('recruiter'), (req: AuthedRequest, res) => {
  const job = load(req.params.id);
  if (!job) return res.status(404).json({ error: 'Job not found' });
  if (job.recruiterId !== req.user!.id) return res.status(403).json({ error: 'Not your job posting' });
  const p = jobBody.partial().safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: 'Invalid job', details: p.error.flatten() });
  const updated = { ...job, ...p.data };
  db.prepare('UPDATE jobs SET data = ? WHERE id = ?').run(JSON.stringify(updated), job.id);
  res.json({ job: updated });
});

jobsRouter.delete('/:id', requireAuth, requireRole('recruiter'), (req: AuthedRequest, res) => {
  const job = load(req.params.id);
  if (!job) return res.status(404).json({ error: 'Job not found' });
  if (job.recruiterId !== req.user!.id) return res.status(403).json({ error: 'Not your job posting' });
  db.transaction(() => {
    db.prepare('DELETE FROM applications WHERE job_id = ?').run(job.id);
    db.prepare('DELETE FROM jobs WHERE id = ?').run(job.id);
  })();
  res.json({ ok: true });
});
