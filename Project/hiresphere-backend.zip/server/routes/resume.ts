import { Router } from 'express';
import { z } from 'zod';
import { GoogleGenAI } from '@google/genai';
import { requireAuth } from '../auth';

export const resumeRouter = Router();
resumeRouter.use(requireAuth);

// Optional AI enhancement: needs GEMINI_API_KEY. Key stays on the server.
resumeRouter.post('/enhance', async (req, res) => {
  const key = process.env.GEMINI_API_KEY;
  if (!key) return res.status(501).json({ error: 'GEMINI_API_KEY is not configured on the server' });
  const p = z.object({
    rawText: z.string().min(20).max(30000),
    targetRole: z.string().max(200).optional(),
  }).safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: 'Provide rawText (20+ characters)' });

  try {
    const ai = new GoogleGenAI({ apiKey: key });
    const result = await ai.models.generateContent({
      model: process.env.GEMINI_MODEL || 'gemini-2.5-flash',
      contents:
        `You are an ATS resume expert. Analyze the resume text below${p.data.targetRole ? ` for the role "${p.data.targetRole}"` : ''}.
Return ONLY JSON: {"atsScore": number 0-100, "atsFeedback": string[], "improvedSummary": string, "suggestedSkills": string[], "bulletRewrites": [{"original": string, "improved": string}]}.

RESUME:
${p.data.rawText}`,
      config: { responseMimeType: 'application/json' },
    });
    res.json({ result: JSON.parse(result.text || '{}') });
  } catch (e: any) {
    console.error('Gemini error:', e?.message);
    res.status(502).json({ error: 'AI service failed. Try again.' });
  }
});
