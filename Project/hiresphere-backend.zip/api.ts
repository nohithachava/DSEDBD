// Frontend client for the HireSphere backend. Vite proxies /api -> http://localhost:4000
import type { UserProfile, Job, JobApplication, CandidateEvaluation } from './types';

const TOKEN_KEY = 'hiresphere_token';
export const getToken = () => localStorage.getItem(TOKEN_KEY);
export const setToken = (t: string | null) =>
  t ? localStorage.setItem(TOKEN_KEY, t) : localStorage.removeItem(TOKEN_KEY);

async function req<T>(path: string, opts: { method?: string; body?: unknown } = {}): Promise<T> {
  const token = getToken();
  const res = await fetch(`/api${path}`, {
    method: opts.method || 'GET',
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data as T;
}

export const api = {
  signup: async (b: { email: string; password: string; role: 'jobseeker' | 'recruiter'; fullName: string; profile?: Partial<UserProfile> }) => {
    const r = await req<{ token: string; user: UserProfile }>('/auth/signup', { method: 'POST', body: b });
    setToken(r.token); return r.user;
  },
  login: async (email: string, password: string) => {
    const r = await req<{ token: string; user: UserProfile }>('/auth/login', { method: 'POST', body: { email, password } });
    setToken(r.token); return r.user;
  },
  logout: () => setToken(null),
  me: () => req<{ user: UserProfile }>('/auth/me').then(r => r.user),
  updateProfile: (p: Partial<UserProfile>) => req<{ user: UserProfile }>('/users/me', { method: 'PUT', body: p }).then(r => r.user),

  jobs: (params: Record<string, string> = {}) =>
    req<{ jobs: Job[] }>(`/jobs?${new URLSearchParams(params)}`).then(r => r.jobs),
  myJobs: () => req<{ jobs: Job[] }>('/jobs/mine').then(r => r.jobs),
  createJob: (j: Partial<Job>) => req<{ job: Job }>('/jobs', { method: 'POST', body: j }).then(r => r.job),
  updateJob: (id: string, j: Partial<Job>) => req<{ job: Job }>(`/jobs/${id}`, { method: 'PUT', body: j }).then(r => r.job),
  deleteJob: (id: string) => req<{ ok: true }>(`/jobs/${id}`, { method: 'DELETE' }),

  apply: (jobId: string, coverNote: string, resumeData?: unknown) =>
    req<{ application: JobApplication; evaluation: CandidateEvaluation }>('/applications', { method: 'POST', body: { jobId, coverNote, resumeData } }),
  myApplications: () => req<{ applications: JobApplication[] }>('/applications/mine').then(r => r.applications),
  recruiterApplications: (jobId?: string) =>
    req<{ applications: JobApplication[] }>(`/applications/recruiter${jobId ? `?jobId=${jobId}` : ''}`).then(r => r.applications),
  setStatus: (id: string, status: JobApplication['status']) =>
    req<{ application: JobApplication }>(`/applications/${id}/status`, { method: 'PATCH', body: { status } }).then(r => r.application),
  withdraw: (id: string) => req<{ ok: true }>(`/applications/${id}`, { method: 'DELETE' }),

  talent: (jobId?: string) =>
    req<{ candidates: { candidate: UserProfile; evaluation?: CandidateEvaluation }[] }>(`/talent${jobId ? `?jobId=${jobId}` : ''}`).then(r => r.candidates),
  enhanceResume: (rawText: string, targetRole?: string) =>
    req<{ result: unknown }>('/resume/enhance', { method: 'POST', body: { rawText, targetRole } }).then(r => r.result),
};
